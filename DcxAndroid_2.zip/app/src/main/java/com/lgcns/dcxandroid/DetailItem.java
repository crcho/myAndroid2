package com.lgcns.dcxandroid;

public class DetailItem {
    public int id;
    public String title;
    public String singer;
    public String melodizer;
    public String lyricist;
    public String genre;
}
