package com.lgcns.dcxandroid;

public class ChartItem {
    public int id;
    public int rank;
    public String title;
    public String singer;
    public String imageFile;
}
